package grocery.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import grocery.Dao.*;
import grocery.model.*;

/**
 * Servlet implementation class Forgot
 */
@WebServlet("/Forgot")
public class Forgot extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Forgot() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out= response.getWriter(); 
		Registermodel obj2=new Registermodel();
		String msg=null;
		String email=request.getParameter("email");
		String sec_qn=request.getParameter("sec_qn");
		String sec_ans=request.getParameter("sec_ans");
		boolean status=ForgotDao.forgot(obj2);
		
		if(status==true){			
			msg="you can change the password";
            out.println("<font color=green size=7>"+msg+"</font>");
	        RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");  
	        rd.include(request,response); 
	  
	    } 
		 else
		 {
			 msg="password not changed";
		 out.println("<font color=green size=7>"+msg+"</font>");
		 RequestDispatcher rd=request.getRequestDispatcher("/for_pass.jsp");  
	        rd.include(request,response);
	    } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


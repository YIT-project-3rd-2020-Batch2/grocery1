package grocery.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import grocery.model.Registermodel;
import grocery.Dao.RegisterDao;

public class Register extends HttpServlet 
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        if(request.getParameter("btn_register")!=null) 
        {
            String name=request.getParameter("txt_name");
            String email=request.getParameter("txt_email");
                                                                
            String password=request.getParameter("txt_password");
            String adds=request.getParameter("txt_adds");
            String ph_no=request.getParameter("txt_ph_no");
            String gender=request.getParameter("txt_gender");
            String sec_qn=request.getParameter("txt_sec_qn");
            String sec_ans=request.getParameter("txt_sec_ans");
            Registermodel registermodel=new Registermodel();
            
            registermodel.setName(name);
            registermodel.setEmail(email);
                                             
            registermodel.setPass(password);
            registermodel.setAdds(adds);
            registermodel.setPh_no(ph_no);
            registermodel.setGender(gender);
            registermodel.setSec_qn(sec_qn);
            registermodel.setSec_ans(sec_ans);
            
            RegisterDao registerdao=new RegisterDao();
            
            String registerValidate=registerdao.authorizeRegister(registermodel);
            if(registerValidate.equals("SUCCESS REGISTER")) 
            {
                request.setAttribute("RegiseterSuccessMsg",registerValidate); 
                RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
                rd.forward(request, response);
            }
            else
            {
                request.setAttribute("RegisterErrorMsg",registerValidate); 
                RequestDispatcher rd=request.getRequestDispatcher("Register.jsp"); 
                rd.include(request, response);
            }
        }
    }

}


package grocery.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import grocery.model.Registermodel;

/**
 * Servlet implementation class Edit
 */
@WebServlet("/Edit")
public class Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       int n=1;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String utype="user";
		String name=request.getParameter("Name");
		String email=request.getParameter("Email Id");
		String adds=request.getParameter("Address");
		String ph_no=request.getParameter("Phone No");
		String pass=request.getParameter("Password"); 
		String pass1=request.getParameter("Confirm Password"); 
		
		if (pass.equals(pass1))
			{
				Registermodel r1=new Registermodel();
				{
				rd=request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				}
			}else
				{
					request.setAttribute("errormsg", "Password mismatch, Please enter the correct password");
					rd=request.getRequestDispatcher("edit.jsp");
					rd.forward(request, response);
				}
	
}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}


		

package grocery.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAOLayer.AdminCategoryDAO;
import DAOLayer.AdminProductDAO;
import Model.Category;


@WebServlet("/Product")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Product product = new Product();
		boolean status = false;
		Category category = new Category();
		AdminProductDAO adminProDAO = new AdminProductDAO();
		AdminCategoryDAO adminCatgDAO = new AdminCategoryDAO();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		String productName= request.getParameter("product_name");
		String productPrice = request.getParameter("product_price");
		String productDesc = request.getParameter("product_desc");
		String productCatg = request.getParameter("category");
		/*byte[] productImage = request.getParameter("product_image").getBytes();*/
		HttpSession adminSession = request.getSession(false);

		if(productName != null && productPrice != null && productDesc != null){
			product.setProductName(productName);
			product.setProductPrice(Double.parseDouble(productPrice));
			product.setProductDesc(productDesc);
			/*product.setProductImage(productImage);*/
			

			try {
				status = adminProDAO.add(product);
			} catch (Exception e) {
				adminSession.setAttribute("exception",e);
				e.printStackTrace();
			}
			if(status == true){
				adminSession.setAttribute("message","You Have Succesfully Added new Product !!!" );
				response.sendRedirect("adminhome.jsp");
			}else{
				adminSession.setAttribute("message","Error !!! You Have Added duplicate Product !!!" );
				response.sendRedirect("adminhome.jsp");
			}
		}else{
			out.println("<script>alert('Write Product Details Again !!!')</script>");
			response.sendRedirect("login.jsp");
		}


	}

	private void setProductDesc(String productDesc) {
		// TODO Auto-generated method stub
		
	}

	private void setProductPrice(double parseDouble) {
		// TODO Auto-generated method stub
		
	}

	private void setProductName(String productName) {
		// TODO Auto-generated method stub
		
	}

}

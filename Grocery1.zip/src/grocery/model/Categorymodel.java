package grocery.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Table(name="CATEGORY")

public class Categorymodel implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Column(name="CATGID")
	private int catgId;
	
	@Column(name="CATGNAME", unique=true, nullable=false)
	private String catgName;

	public Categorymodel() {	}
	
	

	public int getCatgId() {
		return catgId;
	}

	public void setCatgId(int catgId) {
		this.catgId = catgId;
	}

	public String getCatgName() {
		return catgName;
	}

	public void setCatgName(String catgName) {
		this.catgName = catgName;
	}

}


package grocery.Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import grocery.model.*;
public class loginDao {
	
	private static Connection con; 
	private static PreparedStatement stmt;
	public static void getConnection()
	  {
		  try {
		  Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
		  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/grocerydb","root",""); 
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	  }
		  catch(Exception e)
		  {	  e.printStackTrace();	  }  	  
		  
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }
	  
	  public static boolean validate(Registermodel log)
	  {
		  boolean status=false;
		  try{
			  getConnection();
			  stmt=con.prepareStatement("select * from registration where udername=? and pass=?");
			  stmt.setString(1, log.getusername());
			  stmt.setString(2, log.getPass());
			  ResultSet rs=stmt.executeQuery();  
			  status=rs.next(); 
			  
			  closeConnection();
			   return true;
			    }
			  catch(SQLException e)
			  {
			  e.printStackTrace();
			  return false;
			  }
			  catch(Exception e)
			  {
			  e.printStackTrace();
			  return false;
			  }  	  	  
			  
		  }	 
	  public static boolean login(Registermodel log)
		  {
			  boolean status=false;
			  try {
				  getConnection();
				  stmt=con.prepareStatement("select name from registration where username=aaa and pass=111");
				  stmt.setString(1, log.getusername());
				  stmt.setString(2, log.getPass());
				  if(stmt.equals(1))
				  {
					  stmt=con.prepareStatement("select name from registration where username=anusha and pass=12345");
							   if(log.getName()=="admin")
							     return true;
							   else
							    return false;
					  
				  }
				  ResultSet rs=stmt.executeQuery();  
				  status=rs.next(); 
				  
				  closeConnection();
				   return true;
				    }
				  catch(SQLException e)
				  {
				  e.printStackTrace();
				  return false;
				  }
				  catch(Exception e)
				  {
				  e.printStackTrace();
				  return false;
				  }  	  	  
				  
			  }

	  }
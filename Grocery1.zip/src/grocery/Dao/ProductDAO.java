package grocery.Dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import DAOLayer.AdminInterfaceDAO;
import DAOLayer.HibernateUtil;
import Model.Category;
import Model.Product;

public class ProductDAO implements AdminInterfaceDAO{
	private boolean status = false;
	private Product newProduct= null;
	private Session session ;
	private Transaction getTransaction;
	
	public boolean add(Object newObject) {
		newProduct = new Product();
		status = false;
		System.out.println("adding the product .....into database");
		newProduct = (Product)newObject;
		try {
			status =false;
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			session.save(newProduct);
			getTransaction.commit();
			status = true;
		} catch (HibernateException he) {
			
			he.printStackTrace();
			try {
				throw new Exception(he);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}catch(final Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		System.out.println("return true from product addition in table");
		return status;
	}

	@Override
	public boolean remove(int id) throws MappingException {
		try {
			status =false;
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			Query query = session.createQuery("delete from Product where productid="+id);
			int i = query.executeUpdate();
			getTransaction.commit();
			if(i>0){
				status = true;
			}
		} catch (HibernateException he) {
			throw new MappingException(he);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		return status;
	}

	@Override
	public boolean update(Object newObject) throws MappingException {
		Product updateProduct = new Product();
		status = false;
		System.out.println("updating the product .....into database");
		updateProduct = (Product)newObject;
		try {
			status =false;
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			session.get(Product.class, updateProduct.getProductId());
			session.merge(updateProduct);
			getTransaction.commit();
			status = true;
		} catch (HibernateException he) {
			try {
				throw new Exception(he);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}catch(final Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		System.out.println("return true from product addition in table updating....");
		return status;
	}

	@Override
	public List<?> readAll() {
		
		return null;
	}

	public List<?> getProductsByCatg(Category category) throws MappingException {
		List<?> products = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			Query query = session.createQuery("FROM Product where catgid="+category.getCatgId());
			products = query.list();
		} catch (HibernateException he) {
			try {
				throw new Exception(he);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		return products;
	}

	public Product getProductById(int productId) throws MappingException {
		Product product = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			Query query = session.createQuery("FROM Product where productId="+productId);
			product = (Product)query.uniqueResult();
		} catch (HibernateException he) {
			throw new MappingException(he);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		return product;
	}

	public List<?> getProductsByCatg(int catgId) throws MappingException {
		List<?> products = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			getTransaction = session.beginTransaction();
			Query query = session.createQuery("FROM Product where catgid="+catgId);
			products = query.list();
		} catch (HibernateException he) {
			throw new MappingException(he);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			session.close();
		}
		return products;
	}
}

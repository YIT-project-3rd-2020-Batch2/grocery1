package grocery.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import grocery.model.Registermodel;

public class RegisterDao 
{
    public String authorizeRegister(Registermodel registermodel) 
    {
        String name=registermodel.getName();
        String email=registermodel.getEmail();
        String address=registermodel.getAdds();  
        String password=registermodel.getPass();
        String ph_no=registermodel.getPh_no();
        String gender=registermodel.getGender();
        String sec_qn=registermodel.getSec_qn();
        String sec_ans=registermodel.getSec_ans();
        
        String url="jdbc:mysql://localhost:3306/login"; 
        String uname="root"; 
        String pass=""; 
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver"); 
            Connection con=DriverManager.getConnection(url,uname,pass); 
            
            PreparedStatement pstmt=null; 
            pstmt=con.prepareStatement("insert into registration(Name,Email,Pass,Adds,Ph_no,Gender,Sec_qn,Sec_ans) values(?,?,?,?,?,?,?,?)");
			  pstmt.setString(1,name);
			  pstmt.setString(2,email);
			  pstmt.setString(3,password);
			  pstmt.setString(4,address);
			  pstmt.setString(5,ph_no);
			  pstmt.setString(6,gender);
			  pstmt.setString(7,sec_qn);
			  pstmt.setString(8,sec_ans);
			   ResultSet rs=pstmt.executeQuery();  
             
            pstmt.close(); 
            con.close();
           
            return "SUCCESS REGISTER"; 
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
            return "FAIL REGISTER"; 
    }

	

}